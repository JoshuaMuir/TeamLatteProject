/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProjectGraphics;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 *
 * @author Joshua
 */
public class doActionListener implements ActionListener {
    public void actionPerformed(ActionEvent event){
    HelloComponent hi=new HelloComponent();
        System.out.println("workds");
    NotGraphics.jooble.setText("hi");
    }
}
