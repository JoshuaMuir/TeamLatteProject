/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProjectGraphics;



import javax.swing.*;
import java.awt.*;
import java.awt.geom.Area;
import javafx.scene.shape.Circle;
class HelloComponent extends JComponent{
@Override
protected void paintComponent(Graphics g){
super.paintComponent(g);
Graphics2D g2=(Graphics2D)g;
Graphics2D g3=(Graphics2D)g;
Rectangle rect1=new Rectangle(20,400,800,500);
Rectangle rect2=new Rectangle(200,300,800,500);
Rectangle rect3=new Rectangle(500,300,10,100);
 circ3=new Circle(500,300,50);
Rectangle[] guy=new Rectangle[110];
g2.fill(rect3);
int i=0;
int spot=-300;
int trot=300;
int kret=30;
int fret=200;
do{

    guy[i]=new Rectangle(spot,trot,kret,fret);
    
spot+=5;
trot+=5;
if(i%3==0){
kret-=1;
fret-=1;} else;
++i;
}while(i<100);



//g2.setColor(Color.green);

//g2.fill(rect1);
g2.setColor(Color.black);
//g2.fill(guy[0]);
//g2.fill(guy[1]);
Area[] ctr=new Area[110];
int j=0;
ctr[0]=new Area(guy[0]);
while(j<90){
ctr[j]=new Area(guy[j]);

++j;

}
j=0;
while(j<80){

    
g2.setColor(Color.red);
  //ctr[j]=new Area(guy[j]);  
  //ctr[j].add(new Area(guy[j]));
    j++;
    System.out.println("irks");
    if(j<75&&j>2)
        {
    ctr[j].add(new Area(guy[j-1]));System.out.print("orks");}
    else;
}

/*ctr[2].add(new Area(guy[1]));
ctr[3].add(new Area(guy[2]));
ctr[4].add(new Area(guy[3]));
ctr[5].add(new Area(guy[4]));
ctr[6].add(new Area(guy[5]));
ctr[7].add(new Area(guy[6]));
ctr[7].add(new Area(guy[7]));
ctr[8].add(new Area(guy[8]));
ctr[9].add(new Area(guy[9]));
ctr[10].add(new Area(guy[11]));
ctr[11].add(new Area(guy[12]));
ctr[12].add(new Area(guy[13]));*/

//g2.setColor(Color.white);
//g2.fill(rect3);
j=2;
g2.rotate(Math.toRadians(-60));
while(j<70){g2.fill(ctr[j]);++j;}
//g2.fill(ctr[4]);
//g2.fill(ctr[5]);
//Area ar1=new Area(rect1);
//ar1.exclusiveOr(new Area(rect2));
//Area ar2=new Area(rect2);
//Area ar3=new Area(rect3);
//ar2.add(new Area(rect1));
//ar2.subtract(ar1);
//ar3.add(new Area(rect2));
//g2.setColor(Color.red);
//g2.fill(ar2);
g2.setColor(Color.black);
Rectangle prop1=new Rectangle(500,400,30,200);
Area jirp1=new Area(prop1);
ctr[j].add(new Area(jirp1));
//g2.fill(ctr[j]);
g3.rotate(Math.toRadians(60));
g3.fill(rect3);
g3.fill(circ3);
g2.dispose();
}
}