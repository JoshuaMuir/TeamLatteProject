/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mojox
 */
package ProjectGraphics;

import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import javax.swing.*;

public class NotGraphics {

    public static void main(String[] args) {

        runGUI();
    }

    private static void runGUI() {

        Board bird = new Board();
        HelloComponent hi = new HelloComponent();
//Board bird=new Board();
        JFrame froome = new JFrame();
        JPanel panool=new JPanel();
       JPanel prandel=new JPanel();
        
        //froome.setLayout(new FlowLayout());
        froome.setSize(1000, 900);
        froome.setTitle("Score 4");
        froome.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        froome.setVisible(true);
        //panool.setLayout(new GridBagLayout());
        
//hi.add(bird);
 panool.add(bird);
 panool.add(hi);
// froome.getContentPane().add(panool);
    //froome.add(panool);
    //froome.add(prandel);
        froome.add(hi);
    }

}
