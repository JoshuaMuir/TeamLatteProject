package ca.unbc.cpsc.latte;

import ca.unbc.cpsc.score4.enums.GameOverStatus;
import  ca.unbc.cpsc.latte.Board;
import ca.unbc.cpsc.score4.interfaces.Colour;
import ca.unbc.cpsc.score4.interfaces.Location;
import ca.unbc.cpsc.score4.interfaces.*;
import ca.unbc.cpsc.score4.exceptions.PlayerException;
import java.util.Random;

public class AI1 implements ca.unbc.cpsc.score4.interfaces.Player {
    public PlayerColour colour;
    public PlayerColour opponentColour;
    
    private GameOverStatus gameOverStatus;
    
    private int opponent;
    private int turnCount;
    
    public static Board board;
    public static Board board2;
    private Peg[] pegs;
    private Bead[] beads;
    
    private Loc3d lastmove;
    private static int numWins = 0;
    
//    public AI() throws PlayerException{
//        reset();
//    }
    
    public Board getBoard(){
        return board;
    }
    
    public Colour getColour(){
        return colour;
}
    
    @Override
    public void reset() throws PlayerException {
//        gameOverStatus = null;
        colour=PlayerColour.b;
        turnCount = 1;
        board2=new Board();
        board2.changehasWin(false);
        board = new Board();
        board.changehasWin(false);
    }
    
    //@Override
    public void startGameAs(Colour c) throws PlayerException {
        colour = (PlayerColour)c;
        
        if(c == PlayerColour.b)
            opponentColour = PlayerColour.b;
        else
            opponentColour = PlayerColour.w;
    }
    
    @Override
    public void noteOpponentsId(int id) throws PlayerException {
        opponent = id;
    }
    
    @Override
    public void opponentPlays(Location ell) throws PlayerException {
        Loc3d drum=(Loc3d)ell;
        int row = drum.getRow();
        int col = drum.getColumn();
        int height = drum.getHeight();
        System.out.println("CHECK IT OUT ");
        board.getPeg(ell).addBead(0, new Bead(opponentColour, ell, height));
       lastmove=drum;
        System.out.println("TRIPPING OUT OF THE THING");
        //add the opponents last move
        //board.getPeg(lastmove).addBead(0, new Bead(colour, lastmove, lastmove.getHeight()));
        board2.addtoLines(new Bead(colour, lastmove, lastmove.getHeight()));
//add my last move
      board.getPeg(lastmove).addBead(0, new Bead(colour, lastmove, lastmove.getHeight()));
        turnCount += 2;
    }
    
    @Override
    public Loc3d requestMoveLocation() /*throws PlayerException*/ {
        Loc3d move = new Loc3d(0,0,0); //to ensure that move is initialized
        //for choosing a peg at random
       System.out.println("got in here pal");
        int row;
        int column;
        int height;
        
        //for checking vertical lines of 3
        
        Bead b1;
        Bead b2;
        Bead b3;
        
        if(isFirstFour()) { //try to get a corner peg
//          Loc3d old=new Loc3d(3,0,0);
//           System.out.println(board);
//           board.getPeg(old);
            System.out.println("turnCount is "+turnCount);
            //++turnCount;
            if(board.getPeg(new Loc3d(3,0,0)).getLength() == 0) {
                 move = new Loc3d(3, 0, 0);System.out.println("3,0,0");
                 //System.out.println("turnCount is "+turnCount);
            }
            else if(board.getPeg(new Loc3d(3,3,0)).getLength() == 0) {
                 move = new Loc3d(3, 3, 0);System.out.println("3,3,0");
            }
            else if(board.getPeg(new Loc3d(0,0,0)).getLength() == 0) {
                 move = new Loc3d(0, 0, 0);System.out.println("0,0,0");
            }
            else if(board.getPeg(new Loc3d(0,3,0)).getLength() == 0) {
                 move = new Loc3d(0, 3, 0);System.out.println("0,3,0");
            }
        }
        else {
            for(int i = 0; i < board.sz0.length; i++) {
                //loop through all pegs
                System.out.println("we in it");
                if(board.sz0[i].getLength() == 3) { //check if there are vertical lines of 3
                    b1 = board.sz0[i].beadlist[0];
                    b2 = board.sz0[i].beadlist[1];
                    b3 = board.sz0[i].beadlist[2];
                    System.out.println("22222222222222222222222222");
                    if(b1.getColour() == b2.getColour() && b2.getColour() == b3.getColour()) {
                        //check if 3 beads in a line are same colour
                        row = board.sz0[i].getRow();
                        column = board.sz0[i].getColumn();
                        height = board.sz0[i].getLength();
                    System.out.println("indeed we are here");
                        move = new Loc3d(row, column, height);
                        i = board.sz0.length;
//exit loop             //i=board.sz0[].length;
                    }else System.out.println("laskjfa;lskdjfa;lskdfja;lsjdfa;lsjdfha;lskdfha;ldfjas;ldjfa;lskdjfa;lsljdghaljdghakljsldgahklj");
                }
                else{
                    move = randomPlay();System.out.println("111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111");}
            }
        }
        ++turnCount;
        System.out.println("the ai returns something");
        lastmove = move;
        System.out.println("093847523904857234905872907");
         board.getPeg(lastmove).addBead(0, new Bead(colour, lastmove, lastmove.getHeight()));
         //board.addtoLines(new Bead(colour, lastmove, lastmove.getHeight()));
        //add my last move
        return move;
    }
    
    public Location retry() throws PlayerException {
        Loc3d move = requestMoveLocation();
        return move;
}
    
    @Override
    public void noteGameOver(GameOverStatus whatHappened) {
        gameOverStatus = whatHappened;
        
        if(gameOverStatus == GameOverStatus.WIN)
            numWins++;
    }
    
    public int getNumWins() {
        //returns the amount of times AI has ever won a game
        return numWins;
    }
    
    private boolean isFirstFour() {
        return (turnCount < 6);
    }
    
    private Loc3d randomPlay() {
        System.out.println("WE ARE IN THE RANDOMPLAY");
        //method chooses a peg location at random
        Loc3d move = new Loc3d(0,0,0);
        Random random = new Random();
        boolean isLegal = false;
        
        while(!isLegal) {
            System.out.println("IN THE WHILTE");
            int randomIndex = random.nextInt(16);
            
            int row = board.sz0[randomIndex].getRow();
            int col = board.sz0[randomIndex].getColumn();
            int height = board.sz0[randomIndex].getLength();
            
            move = new Loc3d(row, col, height);
            
            if(NotGraphics.joey.checkMove(move)) { //if peg isn't full
                isLegal = true;
            }
        }
        //alternately, I just let the Referee do all the checking and just return whatever random location is generated
        //this is probably what i'll do, cause I should not be calling the Referee check method at all.
        System.out.println("we are in the return");
        return move;
    }
}