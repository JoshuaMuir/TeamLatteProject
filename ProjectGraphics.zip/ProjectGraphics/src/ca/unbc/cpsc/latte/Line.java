package ca.unbc.cpsc.latte;

import static ca.unbc.cpsc.score4.interfaces.NotGraphics.joey;
import ca.unbc.cpsc.score4.interfaces.PlayerColour;

public class Line {

    protected int length = 0;
    protected Bead[] beadlist = new Bead[4];
    public int t=0;
    public int j=0;
    public int[] rowWin;
    //beadlist[0] is at lowest possible height, col, row
    //goes, left to right, bottom to top, smallest row position to largest
    private Board board;
    
    public Line() {
        rowWin=new int[5];
      //  System.out.println("in line goddammit");
       // board = b;
    }

    public void addBead(int i, Bead b) {
        System.out.println("what the fuck did you just fucking say to me you little bitch "+b.getRow());
//        b.isBlack();//i is from 0 to 3
//        if(b.isBlack()&&((b.getRow()==0)||b.getColumn()>=0)){
//            System.out.println("Row is "+b.getRow());
//            System.out.println("Column is "+b.getColumn());
//            System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
//        ++t;
//        System.out.println("The value of t is "+t);
//        }else;
//        if(t==2)System.exit(5);else;
        if (this.length < 4) {
            System.out.println("in the mf line");
            beadlist[j++] = b;
            ++length;
//            beadlist[1].isBlack();
            System.out.println("the length is in fact the following digit"+length);
            if (length == 4) {//System.exit(4);
                System.out.println("we checking some gd beads");
              if (beadlist[0].isBlack()
                      == beadlist[1].isBlack()
                       && beadlist[1].isBlack() == beadlist[2].isBlack()
                        && beadlist[2].isBlack() == beadlist[3].isBlack()){ 
                  if(beadlist[0].isBlack()){joey.whomstdveWon(PlayerColour.b);System.out.println("CAN YOU BELIEVE THAT THE PLAYER WITH COLOR BLACK WON?");}
                  else {joey.whomstdveWon(PlayerColour.w);System.out.println("CAN YOU BELIEVE THAT THE PLAYER WITH COLOR WHITE WON?");}
               // if(true){
                    System.out.println("some mf won goddammit555555555555555555555555555555555555555555555555555555555555555555555555555555555");
                   // System.exit(5);
                   // System.exit(5);
//                    board.changehasWin(true);
             
                }else System.out.print("no mf won goddammit 123123513451349857134895761349857163894571643");
            }
        } else {System.out.println("893201573094576314958723645892736458927356239846");
            //request different move
        }

    }

    public final int getLength() {
        return length;
    }
    
}