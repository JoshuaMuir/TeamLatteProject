/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.unbc.cpsc.latte;
import ca.unbc.cpsc.score4.interfaces.*;
import ca.unbc.cpsc.score4.exceptions.PlayerException;  

/**
 *
 * @author jmuir
 */
public class Referee1 {public static int yurd=0;
    public AI1 deep=new AI1();
    public static int whoWon=0;
//=new AI();
 public Referee1(){
   AI1 deep=new AI1();
   
   
   try{deep.reset();}catch(Exception e){e.printStackTrace();}
 
 }
    public void placeBead(Location l) throws PlayerException{
  Loc3d location2=(Loc3d)l;
    System.out.println("now its here");
    l.getRow();   
  
    deep.opponentPlays(l);
    if(yurd==1)NotGraphics.sendBro(); else;
    System.out.println("After opponent plays");
    NotGraphics.whatIs(l.getRow(), l.getColumn(), location2.getHeight());
   ++NotGraphics.whomTurn;
 ca.unbc.cpsc.score4.interfaces.NotGraphics.mainFrame.setSize(1001,900);
 ca.unbc.cpsc.score4.interfaces.NotGraphics.mainFrame.setSize(1000,900);
    
    
    
    
    }
    public void doThis() throws PlayerException{
//    deep=new AI();
    System.out.println("we are here for some reason");
    
    //deep.reset();
    Loc3d josh=deep.requestMoveLocation();
    NotGraphics.timerThing(josh.getRow(),josh.getColumn(),1);
    
    
    }
    public void checkWin(Location l) throws PlayerException{
    
    System.out.println(AI1.board.getPeg(l));
    
    }
 public boolean checkMove(Location l){
 
 
 return true;
 
 }   
 public void whomstdveWon(PlayerColour c){
     NotGraphics.runerble();
    
     if(c==deep.colour){System.out.println("AI WINS");whoWon=1;}
     else {System.out.println("NOT AI WINS");whoWon=2;}
     endGame();
 }
 private void endGame(){
 try{
     ++yurd;
     NotGraphics.sendBro();
     deep.reset();}catch(PlayerException c){c.printStackTrace();}
     
 }
 public void setColor(){
 
 
 
 }
}
